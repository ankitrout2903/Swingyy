import './style.css';

export default function Home(){
    return (
        <div className="home">Select a friend to start chatting!!</div>
    )
}